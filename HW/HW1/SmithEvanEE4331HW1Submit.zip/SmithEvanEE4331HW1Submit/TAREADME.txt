to TA
please place the data set excel file in both Part1 and Part2 dirs
cd to */ to the Part1 dir and then run the sabatch there
do the same for Part2 as well
let me know if there are any issues bc there shouldnt be
thanks - email: ers131@txstate.edu  